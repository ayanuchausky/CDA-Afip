package examen.Afip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AfipApplication {

	public static void main(String[] args) {
		SpringApplication.run(AfipApplication.class, args);
	}

}
